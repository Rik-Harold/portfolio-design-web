__('Save as Template', 'elementor');
__('Preview Changes', 'elementor');
/* translators: %s: Post type label. */
__('Save Draft', 'elementor');
__('%s Settings', 'elementor');
__('Save Options', 'elementor');
__('Publish', 'elementor');
__('Submit', 'elementor');